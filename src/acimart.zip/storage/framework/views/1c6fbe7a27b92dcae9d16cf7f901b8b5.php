<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Keranjang - Acimart</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-100 font-sans antialiased">
    <header class="bg-white dark:bg-gray-800 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="/" class="text-2xl font-bold text-red-600">Acimart</a>
            <nav class="space-x-6">
                <a href="/" class="hover:text-red-600">Home</a>
                <a href="/cart" class="text-red-600 font-semibold">Keranjang</a>
            </nav>
        </div>
    </header>

    <div class="max-w-7xl mx-auto px-4 py-12">
        <h1 class="text-3xl font-bold text-red-700 mb-8">Keranjang Belanja</h1>
        <?php if(count($cart) > 0): ?>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Item Keranjang -->
            <div class="lg:col-span-2 space-y-4">
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex items-center space-x-4">
                    <img src="<?php echo e(asset('storage/' . $item['gambar'])); ?>" class="w-20 h-20 object-cover rounded">
                    <div class="flex-1">
                        <h3 class="font-semibold"><?php echo e($item['nama']); ?></h3>
                        <p class="text-red-600">Rp <?php echo e(number_format($item['harga'])); ?></p>
                    </div>
                    <div class="flex items-center space-x-2">
                        <button class="bg-red-500 text-white px-2 py-1 rounded">-</button>
                        <span><?php echo e($item['qty']); ?></span>
                        <button class="bg-red-500 text-white px-2 py-1 rounded">+</button>
                    </div>
                    <button class="text-red-500 hover:text-red-700">Hapus</button>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Ringkasan -->
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold mb-4">Ringkasan Belanja</h3>
                <p>Total: <span class="text-red-600 font-bold">Rp <?php echo e(number_format($total)); ?></span></p>
                <button class="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-lg mt-4">Lanjut ke Checkout</button>
            </div>
        </div>
        <?php else: ?>
        <p class="text-center text-gray-500">Keranjang kosong. <a href="/" class="text-red-600">Belanja sekarang</a></p>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\acimart\resources\views/cart.blade.php ENDPATH**/ ?>