<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Checkout - Acimart</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-100 font-sans antialiased">
    <header class="bg-white dark:bg-gray-800 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="/" class="text-2xl font-bold text-red-600">Acimart</a>
            <nav class="space-x-6">
                <a href="/" class="hover:text-red-600">Home</a>
                <a href="/cart" class="hover:text-red-600">Keranjang</a>
            </nav>
        </div>
    </header>

    <div class="max-w-7xl mx-auto px-4 py-12">
        <h1 class="text-3xl font-bold text-red-700 mb-8">Checkout</h1>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Form Alamat -->
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold mb-4">Alamat Pengiriman</h3>
                <form class="space-y-4">
                    <input type="text" placeholder="Nama Lengkap" class="w-full p-3 border rounded">
                    <input type="text" placeholder="Alamat" class="w-full p-3 border rounded">
                    <input type="text" placeholder="Kota" class="w-full p-3 border rounded">
                    <input type="text" placeholder="Kode Pos" class="w-full p-3 border rounded">
                </form>
            </div>

            <!-- Ringkasan dan Pembayaran -->
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold mb-4">Metode Pembayaran</h3>
                <select class="w-full p-3 border rounded mb-4">
                    <option>Transfer Bank</option>
                    <option>E-Wallet</option>
                    <option>COD</option>
                </select>
                <p>Total: <span class="text-red-600 font-bold">Rp <?php echo e(number_format($total)); ?></span></p>
                <button class="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-lg mt-4">Bayar Sekarang</button>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\acimart\resources\views/checkout.blade.php ENDPATH**/ ?>