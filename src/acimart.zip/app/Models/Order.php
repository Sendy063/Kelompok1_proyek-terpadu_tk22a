<?php 

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'customer',
        'order_date',
        'total',
        'status',
    ];
}