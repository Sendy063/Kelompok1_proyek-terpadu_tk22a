<?php

namespace App\Filament\Resources\ProdukTapiokaResource\Pages;

use App\Filament\Resources\ProdukTapiokaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProdukTapioka extends CreateRecord
{
    protected static string $resource = ProdukTapiokaResource::class;
}
